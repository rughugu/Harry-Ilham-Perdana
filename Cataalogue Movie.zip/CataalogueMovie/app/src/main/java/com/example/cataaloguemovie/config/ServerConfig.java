package com.example.cataaloguemovie.config;

public class ServerConfig {
    public static final String URL_BASE = "https://api.themoviedb.org";
    public static final String API_ENDPOINT = URL_BASE;

}
